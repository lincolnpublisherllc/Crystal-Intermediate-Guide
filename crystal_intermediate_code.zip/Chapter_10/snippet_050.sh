build:
	crystal build src/task_api.cr --release
