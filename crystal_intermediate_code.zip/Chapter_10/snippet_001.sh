crystal init app task_api
cd task_api
