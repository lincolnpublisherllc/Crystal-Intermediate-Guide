run:
	crystal run src/my_project.cr
