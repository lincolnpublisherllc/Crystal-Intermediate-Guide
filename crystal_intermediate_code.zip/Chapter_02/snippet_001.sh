crystal init app my_project
