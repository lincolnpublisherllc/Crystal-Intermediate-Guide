crystal build src/my_project.cr --release
