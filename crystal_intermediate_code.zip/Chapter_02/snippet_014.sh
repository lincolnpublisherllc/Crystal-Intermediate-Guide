crystal init app todo_app
