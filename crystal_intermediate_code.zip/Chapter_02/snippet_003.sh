crystal init lib my_library
