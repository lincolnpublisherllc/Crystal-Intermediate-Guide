shards update
