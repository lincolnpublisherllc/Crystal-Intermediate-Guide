CRYSTAL_ENV=development crystal run src/my_project.cr
CRYSTAL_ENV=production crystal build src/my_project.cr --release
