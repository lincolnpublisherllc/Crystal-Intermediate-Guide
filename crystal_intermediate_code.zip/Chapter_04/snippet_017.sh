text = "crystal is fast and crystal is fun"
words = text.split(" ")
