crystal init lib math_lib
