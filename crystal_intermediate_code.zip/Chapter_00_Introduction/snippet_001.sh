crystal init app task_api
shards install
crystal spec
